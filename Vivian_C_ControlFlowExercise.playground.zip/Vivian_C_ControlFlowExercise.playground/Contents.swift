import Cocoa

var greeting = "Hello, playground"

//variables and constants
let totalSeconds = 180
var currentTimer = 180

//control flow
for currentTimer in 1...180 {
        print("\(currentTimer)")
}

//print
if currentTimer == totalSeconds {
    print("Stop!")
} else {
    print("Continue.")
}




